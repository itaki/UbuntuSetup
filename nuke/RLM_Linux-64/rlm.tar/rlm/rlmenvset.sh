#! /bin/bash
#
# License Environment Setting
#
# Ultimate RLM floating license server Uninstaller
# Developed by Ahad Mohebbi


	export fabricinc_LICENSE=5053@localhost
	export foundry_LICENSE=5053@localhost
	export genarts_LICENSE=5053@localhost
	export golaem_LICENSE=5053@localhost
	export innobright_LICENSE=5053@localhost
	export mootzoid_LICENSE=5053@localhost
	export nextlimit_LICENSE=5053@localhost
	export peregrinel_LICENSE=5053@localhost
	export redshift_LICENSE=5053@localhost
	export solidangle_LICENSE=5053@localhost
	export SFX_LICENSE_SERVER=5053@localhost
	export RLM_LICENSE=/opt/rlm

	export PATH=$PATH:fabricinc_LICENSE:foundry_LICENSE:genarts_LICENSE:golaem_LICENSE:innobright_LICENSE:mootzoid_LICENSE:nextlimit_LICENSE:peregrinel_LICENSE:redshift_LICENSE:solidangle_LICENSE:SFX_LICENSE_SERVER:RLM_LICENSE

